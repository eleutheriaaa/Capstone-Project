const { addSkinHandler } = require('./handler');

const routes = [
  {
    method: 'POST',
    path: '/skins',
    handler: addSkinHandler,
  },
];

module.exports = routes;