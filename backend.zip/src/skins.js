const skins = [];
 
module.exports = skins;