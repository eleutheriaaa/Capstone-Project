const fs = require('fs');
const path = require('path');
const { nanoid } = require('nanoid');
const skins = require('./skins');

const addSkinHandler = async (request, h) => {
  const { image } = request.payload;
  const id = nanoid(16);
  const createdAt = new Date().toISOString();

  const filename = `${id}.jpg`;
  const filepath = path.join(__dirname, 'uploads', filename);

  const fileStream = fs.createWriteStream(filepath);
  await new Promise((resolve, reject) => {
    image.pipe(fileStream);
    image.on('end', resolve);
    image.on('error', reject);
  });

  const newSkin = {
    id, filename, createdAt,
  };
 
  skins.push(newSkin);

  const isSuccess = skins.filter((skin) => skin.id === id).length > 0;

  if (isSuccess) {
    const response = h.response({
      status: 'success',
      message: 'Catatan berhasil ditambahkan',
      data: {
        noteId: id,
      },
    });
    response.code(201);
    return response;
  }
 
  const response = h.response({
    status: 'fail',
    message: 'Catatan gagal ditambahkan',
  });
  response.code(500);
  return response;
};

module.exports = { addSkinHandler };