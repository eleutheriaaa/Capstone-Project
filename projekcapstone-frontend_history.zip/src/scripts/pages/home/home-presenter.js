export default class HomePresenter {
  #view;
  #model;

  constructor({ view, model }) {
    this.#view = view;
    this.#model = model;
  }

  async uploadImage(imageBlob) {
    const response = await this.#model.uploadImage(imageBlob);
    if (!response.ok) {
      this.#view.showAnalysisError(response.message);
      return null;
    }
    return response.data;
  }

async analyzeImage(data) {
    this.#view.showSubmitLoadingButton();
    try {
      const analysisResponse = await this.#model.analyzeImage(data);

      if (!analysisResponse.ok) {
        console.error('analyzeImage: response:', analysisResponse);
        this.#view.showAnalysisError(analysisResponse.message);
        return;
      }

      const saveResponse = await this.#model.saveAnalysisResult({
        image: data.image,
        diagnosis: analysisResponse.diagnosis,
        confidence: analysisResponse.confidence,
        description: analysisResponse.description,
        treatment: analysisResponse.treatment,
      });

      if (!saveResponse.ok) {
        console.error('Failed to save analysis history:', saveResponse.message);
      }

      this.#view.showAnalysisResults({
        diagnosis: analysisResponse.diagnosis,
        confidence: analysisResponse.confidence,
        description: analysisResponse.description,
        treatment: analysisResponse.treatment,
      });
    } catch (error) {
      console.error('analyzeImage: error:', error);
      this.#view.showAnalysisError(error.message);
    } finally {
      this.#view.hideSubmitLoadingButton();
    }
  }

  async processImage(imageBlob) {
    this.#view.showSubmitLoadingButton();

    try {
      const uploadData = await this.uploadImage(imageBlob);
      if (!uploadData) return;

      const analysis = await this.analyzeImage(imageBlob);
      if (!analysis) return;

      window.location.hash = `/results?id=${uploadData.id}&predictedClass=${encodeURIComponent(analysis.predictedClass)}&confidence=${analysis.confidence}`;
    } catch (error) {
      console.error('processImage: error:', error);
      this.#view.showAnalysisError(error.message);
    } finally {
      this.#view.hideSubmitLoadingButton();
    }
  }
}
