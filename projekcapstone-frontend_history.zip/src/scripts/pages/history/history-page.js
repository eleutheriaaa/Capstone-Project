import {
  generateLoaderAbsoluteTemplate,
  generateHistoryItemTemplate,
  generateHistoryListEmptyTemplate,
  generateHistoryListErrorTemplate,
} from '../../templates.js';
import HistoryPresenter from './history-presenter';
import * as API from '../../data/api'; // Import your existing API module

export default class HistoryPage {
  #presenter = null;

  async render() {
    return `
    <section id="history-section" class="container" tabindex="-1">
      <div class="classification-header">
        <h1 class="section-title">Analysis History</h1>
        <p class="section-subtitle">View your previous skin condition analyses</p>
      </div>
      
      <div class="history-list__container">
        <div id="history-list"></div>
        <div id="history-list-loading-container"></div>
      </div>
    </section>
    `;
  }

  async afterRender() {
    this.#presenter = new HistoryPresenter({
      view: this,
      model: {
        getAnalysisHistory: API.getAnalysisHistory, // Use the function from your existing API
        saveAnalysisResult: API.saveAnalysisResult, // Use the function from your existing API
      },
    });
    await this.#presenter.initialHistoryList();
  }

  populateHistoryList(message, historyItems) {
    const listHistory = historyItems || [];

    if (listHistory.length <= 0) {
      this.populateHistoryListEmpty();
      return;
    }

    // Sort by date (newest first)
    const sortedHistory = listHistory.sort((a, b) => 
      new Date(b.createdAt) - new Date(a.createdAt)
    );

    const html = sortedHistory.reduce((accumulator, history) => {
      return accumulator + generateHistoryItemTemplate({
        id: history.id,
        diagnosis: history.diagnosis,
        confidence: history.confidence,
        description: history.description,
        treatment: history.treatment,
        imageUrl: history.imageUrl,
        createdAt: history.createdAt
      });
    }, '');

    document.getElementById('history-list').innerHTML = `
      <div class="history-list">${html}</div>
    `;

    // Add click handlers for each history item if needed
    document.querySelectorAll('.history-item').forEach(item => {
      item.addEventListener('click', () => {
        // Handle history item click if needed
      });
    });
  }

  populateHistoryListEmpty() {
    document.getElementById('history-list').innerHTML = generateHistoryListEmptyTemplate();
  }

  populateHistoryListError(message) {
    document.getElementById('history-list').innerHTML = generateHistoryListErrorTemplate(message);
  }

  showLoading() {
    document.getElementById('history-list-loading-container').innerHTML =
      generateLoaderAbsoluteTemplate();
  }

  hideLoading() {
    document.getElementById('history-list-loading-container').innerHTML = '';
  }

  // Optional: Add method to handle deletion if your API supports it
  async deleteHistoryItem(id) {
    try {
      // You would need to add this method to your api.js
      const response = await API.deleteAnalysisHistory(id);
      if (response.ok) {
        await this.#presenter.initialHistoryList(); // Refresh the list
      } else {
        console.error('Failed to delete history item:', response.message);
      }
    } catch (error) {
      console.error('Error deleting history item:', error);
    }
  }
}