export default class HistoryPresenter {
  #view;
  #model;

  constructor({ view, model }) {
    this.#view = view;
    this.#model = model;
  }

  async initialHistoryList() {
    this.#view.showLoading();
    try {
      const response = await this.#model.getAnalysisHistory();

      if (!response.ok) {
        console.error('initialHistoryList: response:', response);
        this.#view.populateHistoryListError(response.message);
        return;
      }

      this.#view.populateHistoryList(response.message, response.listHistory);
    } catch (error) {
      console.error('initialHistoryList: error:', error);
      this.#view.populateHistoryListError(error.message);
    } finally {
      this.#view.hideLoading();
    }
  }
}