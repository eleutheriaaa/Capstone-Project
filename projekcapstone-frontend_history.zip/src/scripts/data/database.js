import { openDB } from 'idb';

const DATABASE_NAME = 'story';
const DATABASE_VERSION = 1;
const OBJECT_STORE_NAME = 'saved-stories';

const dbPromise = openDB(DATABASE_NAME, DATABASE_VERSION, {
  upgrade: (database) => {
    database.createObjectStore(OBJECT_STORE_NAME, {
      keyPath: 'id',
    });
  },
});

const Database = {
async addHistoryItem(historyItem) {
    const db = await this._getDB();
    const tx = db.transaction('history', 'readwrite');
    const store = tx.objectStore('history');
    await store.add(historyItem);
    return tx.complete;
  },

  async getAllHistory() {
    const db = await this._getDB();
    const tx = db.transaction('history', 'readonly');
    const store = tx.objectStore('history');
    return store.getAll();
  },

  async deleteHistoryItem(id) {
    const db = await this._getDB();
    const tx = db.transaction('history', 'readwrite');
    const store = tx.objectStore('history');
    await store.delete(id);
    return tx.complete;
  },

  // Initialize the database with history store
  async _initDB() {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open('SkinDiseaseDB', this._dbVersion);

      request.onupgradeneeded = (event) => {
        const db = event.target.result;
        
        if (!db.objectStoreNames.contains('stories')) {
          db.createObjectStore('stories', { keyPath: 'id' });
        }
        
        if (!db.objectStoreNames.contains('history')) {
          db.createObjectStore('history', { keyPath: 'id' });
        }
      };

      request.onsuccess = (event) => {
        resolve(event.target.result);
      };

      request.onerror = (event) => {
        reject(event.target.error);
      };
    });
  }
};

export default Database;
