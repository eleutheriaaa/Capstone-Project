import { getAccessToken } from '../utils/auth';
import { BASE_URL } from '../config';

const ENDPOINTS = {
  REGISTER: `${BASE_URL}/registration`,
  LOGIN: `${BASE_URL}/login`,
  MY_USER_INFO: `${BASE_URL}/users/me`,
  UPLOAD_IMAGE: `${BASE_URL}/uploads`,
  GET_ANALYSIS_HISTORY: `${BASE_URL}/analyses`,
  SAVE_ANALYSIS_RESULT: `${BASE_URL}/analyses`,
};

export async function getRegistered({ username, email, password }) {
  const data = JSON.stringify({ username, email, password });

  const fetchResponse = await fetch(ENDPOINTS.REGISTER, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: data,
  });
  const json = await fetchResponse.json();

  return {
    ...json,
    ok: fetchResponse.ok,
  };
}

export async function getLogin({ email, password }) {
  const data = JSON.stringify({ email, password });

  const fetchResponse = await fetch(ENDPOINTS.LOGIN, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: data,
  });
  const json = await fetchResponse.json();

  return {
    ...json,
    ok: fetchResponse.ok,
  };
}

export async function getMyUserInfo() {
  const accessToken = getAccessToken();

  const fetchResponse = await fetch(ENDPOINTS.MY_USER_INFO, {
    headers: { Authorization: `Bearer ${accessToken}` },
  });
  const json = await fetchResponse.json();

  return {
    ...json,
    ok: fetchResponse.ok,
  };
}


export async function analyzeImage(imageBlob) {
  try {
    const formData = new FormData();
    formData.append('file', imageBlob);

    const response = await fetch('http://127.0.0.1:5000/predict', {
      method: 'POST',
      body: formData
    });

    if (!response.ok) {
      return {
        ok: false,
        message: 'Failed to analyze image'
      };
    }

    const data = await response.json();
    return {
      ok: true,
      predictedClass: data.predicted_class,
      confidence: data.confidence,
      // Add these fields to match your backend response
      diagnosis: data.diagnosis,
      description: data.description,
      treatment: data.treatment
    };
  } catch (error) {
    return {
      ok: false,
      message: error.message
    };
  }
}

export async function getAnalysisHistory() {
  try {
    const response = await fetch(ENDPOINTS.GET_ANALYSIS_HISTORY, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${getAccessToken()}`,
      },
    });

    const responseJson = await response.json();

    if (!response.ok) {
      return {
        ok: false,
        message: responseJson.message || 'Failed to fetch analysis history',
      };
    }

    return {
      ok: true,
      message: 'Analysis history fetched successfully',
      listHistory: responseJson.data,
    };
  } catch (error) {
    return {
      ok: false,
      message: error.message,
    };
  }
}

export async function saveAnalysisResult(data) {
  try {
    const formData = new FormData();
    formData.append('image', data.image);
    formData.append('diagnosis', data.diagnosis);
    formData.append('confidence', data.confidence);
    formData.append('description', data.description);
    formData.append('treatment', data.treatment);

    const response = await fetch(ENDPOINTS.SAVE_ANALYSIS_RESULT, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${getAccessToken()}`,
      },
      body: formData,
    });

    const responseJson = await response.json();

    if (!response.ok) {
      return {
        ok: false,
        message: responseJson.message || 'Failed to save analysis result',
      };
    }

    return {
      ok: true,
      message: 'Analysis result saved successfully',
      data: responseJson.data,
    };
  } catch (error) {
    return {
      ok: false,
      message: error.message,
    };
  }
}

export async function getUploadDetail(id) {
  const accessToken = getAccessToken();

  const response = await fetch(`${BASE_URL}/upload-detail/${id}`, {
    headers: {
      Authorization: `Bearer ${accessToken}`,
    },
  });
  const json = await response.json();

  return {
    ...json,
    ok: response.ok,
  };
}

export async function uploadImage(imageBlob) {
  try {
    const formData = new FormData();
    formData.append('image', imageBlob);

    const response = await fetch(ENDPOINTS.UPLOAD_IMAGE, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${getAccessToken()}`,
      },
      body: formData,
    });

    if (!response.ok) {
      const err = await response.json();
      return {
        ok: false,
        message: err.message || 'Gagal upload gambar',
      };
    }

    const result = await response.json();
    return {
      ok: true,
      data: result.data,
    };
  } catch (error) {
    return {
      ok: false,
      message: error.message,
    };
  }
}