import { showFormattedDate } from './utils';

export function generateLoaderTemplate() {
  return `
    <div class="loader"></div>
  `;
}

export function generateLoaderAbsoluteTemplate() {
  return `
    <div class="loader loader-absolute"></div>
  `;
}

export function generateMainNavigationListTemplate() {
  return `
    <li><a id="bookmark-button" class="bookmark-button" href="#/history">Classification History</a></li>
  `;
}

export function generateUnauthenticatedNavigationListTemplate() {
  return `
    <li><a id="login-button" href="#/login">Login</a></li>
    <li><a id="register-button" href="#/register">Register</a></li>
  `;
}

export function generateAuthenticatedNavigationListTemplate() {
  return `
    <li><a id="logout-button" class="logout-button" href="#/logout"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
  `;
}

export function generateHistoryItemTemplate({
  id,
  diagnosis,
  confidence,
  description,
  treatment,
  imageUrl,
  createdAt,
}) {
  return `
    <div tabindex="0" class="history-item" data-historyid="${id}">
      <div class="history-item__image-container">
        <img class="history-item__image" src="${imageUrl}" alt="Analyzed skin condition">
      </div>
      <div class="history-item__body">
        <div class="history-item__main">
          <h2 class="history-item__diagnosis">${diagnosis}</h2>
          <div class="history-item__confidence">
            Confidence: ${confidence}%
          </div>
          <div class="history-item__createdat">
            <i class="fas fa-calendar-alt"></i> ${showFormattedDate(createdAt, 'id-ID')}
          </div>
        </div>
        <div class="history-item__description">
          ${description || 'No description available'}
        </div>
        <div class="history-item__treatment">
          <strong>Treatment:</strong> ${treatment || 'No treatment recommendation'}
        </div>
      </div>
    </div>
  `;
}

export function generateHistoryListEmptyTemplate() {
  return `
    <div id="history-list-empty" class="history-list__empty">
      <h2>No analysis history available</h2>
      <p>You haven't analyzed any skin conditions yet.</p>
    </div>
  `;
}

export function generateHistoryListErrorTemplate(message) {
  return `
    <div id="history-list-error" class="history-list__error">
      <h2>Error loading analysis history</h2>
      <p>${message ? message : 'Please try again later or contact support.'}</p>
    </div>
  `;
}