import RegisterPage from '../pages/auths/register/register-page';
import LoginPage from '../pages/auths/login/login-page';
import HomePage from '../pages/home/home-page';
import HistoryPage from '../pages/history/history-page';
import ResultsPage from '../pages/results/results-page';
import NotFoundPage from '../pages/not-found/not-found-page';
import { checkAuthenticatedRoute, checkUnauthenticatedRouteOnly } from '../utils/auth';

export const routes = {
  '/login': () => checkUnauthenticatedRouteOnly(new LoginPage()),
  '/register': () => checkUnauthenticatedRouteOnly(new RegisterPage()),
  '/': () => checkAuthenticatedRoute(new HomePage()),
  '/results': () => checkAuthenticatedRoute(new ResultsPage()),
  '/history': () => checkAuthenticatedRoute(new HistoryPage()),
  '*': () => new NotFoundPage(),
};
