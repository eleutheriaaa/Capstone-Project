export const ACCESS_TOKEN_KEY = 'accessToken';

export const BASE_URL = 'http://localhost:7000';